# Reviewer Checklist

## Required files present (SUBMISSION/)
- [ ] 01_project_proposal.md
- [ ] 02_red_teaming_charter.md
- [ ] 03_vulnerability_log.md
- [ ] 04_executive_summary.md
- [ ] 05_repro_steps.md
- [ ] 06_trivy_report.json
- [ ] evidence/ folder with at least one artifact

## Reproducibility
- [ ] Commands in 05_repro_steps.md run as written
- [ ] Trivy report is valid JSON and generated from scanning the Docker image

## Offensive requirements
- [ ] Image evasion: clean label correct, adversarial flips label
- [ ] RAG poisoning: poison doc appears in top-k retrieval for a target query

## Documentation quality
- [ ] Vulnerability log contains severity, impact, evidence, and recommendation
- [ ] Executive summary explains business impact and prioritizes mitigations
