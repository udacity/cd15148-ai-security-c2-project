# Reproduction Steps

> Replace paths/filenames as needed. Commands must run on your machine.

## A) Docker build
```bash
cd finance-ai-redteam
docker build -t finance-ai-redteam -f docker/Dockerfile .
```

## B) Trivy scan + JSON artifact
```bash
chmod +x security/trivy_scan.sh
./security/trivy_scan.sh finance-ai-redteam SUBMISSION/06_trivy_report.json
```

## C) Image evasion (FGSM)
1) Train a model (or use provided checkpoint):
```bash
python classifier/train.py --data_dir ./dataset --epochs 3 --out receipt_model.pt
```
2) Run FGSM attack and save adversarial image:
```bash
python classifier/attacks_fgsm.py --model receipt_model.pt --image ./sample.jpg --true_label receipt --eps 0.02 --out SUBMISSION/evidence/adv_sample.png
```
3) Record console output + save to:
- `SUBMISSION/evidence/fgsm_run_output.txt`

## D) RAG poisoning test
```bash
python rag_chatbot/attacks_rag.py > SUBMISSION/evidence/rag_attack_output.txt
```

## E) What to submit
Zip the entire `SUBMISSION/` folder and upload it.
