# Red Teaming Charter — Finance AI Systems

## 1) Engagement Overview
**Objective:** Identify and validate offensive AI attack paths against:
1) Receipt/No Receipt image classifier
2) Expense RAG Chatbot (policy Q&A)

**Business Outcome:** Reduce fraud, prevent policy bypass, and protect sensitive financial/employee data.

## 2) In-Scope Assets
- Classifier model + inference path
- RAG ingestion pipeline + vector store
- Chat API
- Policy knowledge base documents

## 3) Out of Scope
- Real production data
- DoS / resource exhaustion attacks
- Non-project enterprise systems

## 4) Threat Model Assumptions
- Attacker can upload images and submit chat prompts
- Attacker may introduce documents into the RAG corpus (poisoning scenario)
- Attacker goals: approval bypass, policy manipulation, data exposure

## 5) Required Attack Categories
### A) Image Model Attacks
- Evasion (FGSM)

### B) RAG / LLM Attacks
- Direct prompt injection
- Indirect prompt injection via retrieved documents
- Retrieval poisoning
- Data exfil probes (system prompt/secrets attempts)

## 6) Evidence Requirements
- Commands executed
- Inputs and outputs (images/prompts/docs)
- Saved artifacts in `SUBMISSION/evidence/`

## 7) Success Criteria
- At least one successful classifier evasion (clean correct → adversarial flipped)
- Poisoned document retrieved in top-k for target query
- Clear, prioritized mitigations
