# Project Proposal — Finance AI Red Team: Receipt Classifier + Expense RAG

## Overview
This project evaluates offensive AI risks in a finance/expense context by building and red teaming:
1) A **Receipt/No-Receipt image classifier** for expense submission workflows.
2) An **Expense Policy RAG chatbot** that answers reimbursement and travel policy questions using internal documents.

## Why Finance
Expense systems combine:
- Sensitive financial artifacts (receipts, merchants, totals)
- Policy enforcement (fraud + compliance constraints)
- Automated decisioning (approval/denial based on model outputs)
- LLM reasoning layers (RAG) that introduce injection and data exposure risk

## Scope
### In-scope
- Classifier training + inference scripts
- RAG ingestion + retrieval pipeline + chat API
- Dockerization + supply chain scan artifacts (Trivy JSON)

### Out-of-scope
- Production data
- Denial-of-service testing
- Lateral movement outside the provided app

## Required Attacks
### Image System
- Evasion attack (FGSM) with evidence of label flip

### RAG System
- Prompt injection attempt(s)
- Retrieval poisoning test (poison doc influences retrieval results for target query)
- Data exfil probes (attempts to extract system instructions / secrets)

## Deliverables
- Red Teaming Charter
- Vulnerability Log
- Executive Summary
- Repro steps + evidence artifacts
- Trivy scan JSON report

## Success Criteria
- Systems run locally and in Docker
- Attacks are reproducible from scripts/commands
- Findings are documented with severity + impact + mitigations
