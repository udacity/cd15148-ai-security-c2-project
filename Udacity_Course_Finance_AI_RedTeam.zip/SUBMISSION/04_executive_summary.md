# Executive Summary — Finance AI Red Team Results

## 1) What We Tested
- Receipt/No Receipt classifier used in expense workflows
- Expense RAG Chatbot that answers reimbursement/policy questions from internal docs

## 2) Top Findings
1. **[Finding Title]** — Impact: [Fraud / data exposure / audit risk]
2. **[Finding Title]** — Impact: [Policy bypass / integrity loss]
3. **[Finding Title]** — Impact: [Operational or reputational risk]

## 3) Why It Matters
If exploited, these weaknesses could enable fraudulent reimbursements, policy manipulation, and reduced audit defensibility.

## 4) Prioritized Recommendations
**Immediate (0–2 weeks):**
- [Control]

**Near-term (2–6 weeks):**
- [Control]

**Strategic (6–12 weeks):**
- [Control]

## 5) Evidence Snapshot
- Attacks executed: [count]
- Successful compromises: [count]
- Artifacts: adversarial images, poisoned docs, transcripts, Trivy JSON
