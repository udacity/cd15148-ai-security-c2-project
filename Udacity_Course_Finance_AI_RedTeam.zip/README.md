# Udacity Submission Bundle — Finance AI Red Team Project

This bundle contains:
- `finance-ai-redteam/` — full runnable project source (classifier + RAG + Docker + Trivy script)
- `SUBMISSION/` — Udacity-formatted submission artifacts (what the learner turns in)
- `SOLUTION_REFERENCE/` — reference outputs + example filled artifacts (for reviewers/instructors)

## What the learner submits (minimum)
Upload the contents of the `SUBMISSION/` folder (or zip that folder) per Udacity instructions.

## Quick verification (reviewer/instructor)
1) Build image:
   ```bash
   cd finance-ai-redteam
   docker build -t finance-ai-redteam -f docker/Dockerfile .
   ```
2) Run Trivy:
   ```bash
   chmod +x security/trivy_scan.sh
   ./security/trivy_scan.sh finance-ai-redteam security/trivy_report.json
   ```
3) Run RAG API:
   ```bash
   cd rag_chatbot
   uvicorn app:app --host 0.0.0.0 --port 8000
   ```
4) Run attacks:
   ```bash
   python classifier/attacks_fgsm.py --model receipt_model.pt --image sample.jpg --true_label receipt --eps 0.02 --out adv.png
   python rag_chatbot/attacks_rag.py
   ```
