# Example Executive Summary (Filled)

## What We Tested
- Receipt/No-Receipt classifier used in expense workflows
- Expense policy RAG chatbot backed by internal documents

## Top Findings
1) **Classifier evasion (FGSM)** enables an attacker to flip receipt detection on an otherwise correctly classified image.
   **Business impact:** increases likelihood of fraudulent reimbursements and reduces audit defensibility.

2) **Retrieval poisoning** allows a malicious document to be retrieved for a core policy question, creating a path to policy manipulation.
   **Business impact:** incorrect reimbursement guidance and governance/control integrity degradation.

## Recommendations (Prioritized)
**Immediate:** restrict RAG corpus provenance; add integrity checks; ban untrusted uploads into KB.

**Near-term:** implement adversarial training / robust preprocessing for classifier; implement injection-aware retrieval filtering.

**Strategic:** add monitoring and QA gates for AI outputs used in finance decisioning.
