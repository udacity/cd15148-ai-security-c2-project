# Submission Instructions

Submit a single ZIP containing **all files in `SUBMISSION/`**.

Your submission must include:
1. `01_project_proposal.md`
2. `02_red_teaming_charter.md`
3. `03_vulnerability_log.md`
4. `04_executive_summary.md`
5. `05_repro_steps.md`
6. `06_trivy_report.json` (generated from local scan)
7. Evidence artifacts (as applicable):
   - Adversarial image(s): `evidence/adv_*.png`
   - Prompt injection transcripts: `evidence/prompt_injection_*.md`
   - Poisoned doc sample: `evidence/poison_doc.md`
   - Logs / screenshots (optional)

## Repro requirement
`05_repro_steps.md` must contain **exact commands** to reproduce:
- At least one successful image evasion (clean correct → adversarial flipped)
- At least one successful RAG poisoning influence (poisoned doc retrieved for a relevant query)
- Trivy scan JSON artifact generation

## Academic integrity note
You may use starter code, but your write-up must reflect your own analysis and results.
