# Grading Rubric

## 1) Functionality & Completeness (40%)
**Meets Expectations**
- Receipt/No-Receipt classifier runs and produces predictions.
- Expense RAG system ingests policy docs and retrieves relevant excerpts.
- Docker build succeeds.

**Exceeds Expectations**
- Clear dataset expectations + evaluation metrics reported.
- RAG answers are generated via an LLM integration (optional) with safe prompting.

## 2) Security & Offensive Testing (30%)
**Meets Expectations**
- One successful image evasion attack demonstrated with evidence.
- One successful RAG poisoning/injection impact demonstrated at retrieval layer (poison doc retrieves for target query).

**Exceeds Expectations**
- Multiple attack variants (different epsilons/images; multiple poisoning prompts).
- Discussion of threat model assumptions and realistic attacker constraints.

## 3) Documentation & Communication (20%)
**Meets Expectations**
- Charter, vulnerability log, and executive summary are complete, coherent, and actionable.
- Repro steps are clear and complete.

**Exceeds Expectations**
- Business impact language is strong (finance fraud, audit defensibility, data exposure).
- Mitigation recommendations are prioritized and specific.

## 4) Supply Chain Hygiene (10%)
**Meets Expectations**
- Trivy scan executed locally and JSON report included.

**Exceeds Expectations**
- Remediation plan for top findings (pin versions, reduce attack surface, remove unused packages).
