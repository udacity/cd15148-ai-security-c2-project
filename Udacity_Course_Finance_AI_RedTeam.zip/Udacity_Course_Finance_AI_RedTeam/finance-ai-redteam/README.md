# Finance AI Red Team Project

## Components
- `classifier/`: Receipt vs No-Receipt image classifier + FGSM evasion script
- `rag_chatbot/`: Expense policy RAG chatbot (retrieval-only safe mode) + poisoning test
- `docker/`: Dockerfile
- `security/`: Trivy scan script
- `templates/`: red team reporting templates

## Running locally

### RAG API
```bash
cd rag_chatbot
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8000
```

### Poisoning test
```bash
python attacks_rag.py
```

### Classifier
```bash
cd ../classifier
pip install -r requirements.txt
python train.py --data_dir ./dataset --epochs 3 --out receipt_model.pt
python predict.py --model receipt_model.pt --image ./sample.jpg
python attacks_fgsm.py --model receipt_model.pt --image ./sample.jpg --true_label receipt --eps 0.02 --out adv.png
```

### Docker + Trivy
```bash
cd ..
chmod +x security/trivy_scan.sh
./security/trivy_scan.sh finance-ai-redteam:latest security/trivy_report.json
```
