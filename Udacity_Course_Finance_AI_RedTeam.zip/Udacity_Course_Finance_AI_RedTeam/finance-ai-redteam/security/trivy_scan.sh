#!/usr/bin/env bash
set -euo pipefail

IMAGE_NAME="${1:-finance-ai-redteam:latest}"
OUT_JSON="${2:-security/trivy_report.json}"

mkdir -p "$(dirname "$OUT_JSON")"

echo "[*] Building docker image: $IMAGE_NAME"
docker build -t "$IMAGE_NAME" -f docker/Dockerfile .

echo "[*] Running Trivy scan (JSON output): $OUT_JSON"
trivy image --format json --output "$OUT_JSON" "$IMAGE_NAME"

echo "[+] Done. Report saved to: $OUT_JSON"
