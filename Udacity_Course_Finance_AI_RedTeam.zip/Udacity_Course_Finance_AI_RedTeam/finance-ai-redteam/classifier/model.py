import torch.nn as nn
from torchvision import models

class ReceiptBinaryClassifier(nn.Module):
    def __init__(self):
        super().__init__()
        base = models.resnet18(weights=models.ResNet18_Weights.DEFAULT)
        in_features = base.fc.in_features
        base.fc = nn.Linear(in_features, 2)
        self.net = base

    def forward(self, x):
        return self.net(x)
