import argparse
import torch
from PIL import Image
from torchvision import transforms
from model import ReceiptBinaryClassifier

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--image", required=True)
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    ckpt = torch.load(args.model, map_location=device)
    classes = ckpt["classes"]

    model = ReceiptBinaryClassifier().to(device)
    model.load_state_dict(ckpt["model_state"])
    model.eval()

    tfm = transforms.Compose([transforms.Resize((224, 224)), transforms.ToTensor()])
    img = Image.open(args.image).convert("RGB")
    x = tfm(img).unsqueeze(0).to(device)

    with torch.no_grad():
        logits = model(x)
        probs = torch.softmax(logits, dim=1).squeeze(0).cpu()
        pred = int(probs.argmax().item())

    print({
        "pred": classes[pred],
        "confidence": float(probs[pred].item()),
        "probs": {classes[i]: float(probs[i]) for i in range(len(classes))}
    })

if __name__ == "__main__":
    main()
