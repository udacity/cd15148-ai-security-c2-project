import os
import argparse
from tqdm import tqdm
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
from sklearn.metrics import classification_report
from model import ReceiptBinaryClassifier

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", required=True, help="Folder with train/ and val/ subfolders, each with receipt/ and no_receipt/")
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--batch_size", type=int, default=32)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--out", default="receipt_model.pt")
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"

    tfm = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
    ])

    train_ds = datasets.ImageFolder(os.path.join(args.data_dir, "train"), transform=tfm)
    val_ds   = datasets.ImageFolder(os.path.join(args.data_dir, "val"), transform=tfm)

    train_dl = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True)
    val_dl   = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False)

    model = ReceiptBinaryClassifier().to(device)
    opt = torch.optim.Adam(model.parameters(), lr=args.lr)
    loss_fn = nn.CrossEntropyLoss()

    for epoch in range(args.epochs):
        model.train()
        pbar = tqdm(train_dl, desc=f"epoch {epoch+1}/{args.epochs}")
        for x, y in pbar:
            x, y = x.to(device), y.to(device)
            opt.zero_grad()
            logits = model(x)
            loss = loss_fn(logits, y)
            loss.backward()
            opt.step()
            pbar.set_postfix(loss=float(loss.item()))

        model.eval()
        all_y, all_p = [], []
        with torch.no_grad():
            for x, y in val_dl:
                x = x.to(device)
                logits = model(x)
                preds = logits.argmax(dim=1).cpu()
                all_y.extend(y.numpy().tolist())
                all_p.extend(preds.numpy().tolist())

        print(classification_report(all_y, all_p, target_names=train_ds.classes))

    torch.save({"model_state": model.state_dict(), "classes": train_ds.classes}, args.out)
    print(f"Saved model to: {args.out}")

if __name__ == "__main__":
    main()
