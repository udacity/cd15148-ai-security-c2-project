import argparse
import torch
import torch.nn as nn
from PIL import Image
from torchvision import transforms
from model import ReceiptBinaryClassifier

def fgsm_attack(x, grad, eps):
    x_adv = x + eps * grad.sign()
    return torch.clamp(x_adv, 0.0, 1.0)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--image", required=True)
    ap.add_argument("--true_label", required=True, help="receipt or no_receipt (folder class name)")
    ap.add_argument("--eps", type=float, default=0.02)
    ap.add_argument("--out", default="adv.png")
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    ckpt = torch.load(args.model, map_location=device)
    classes = ckpt["classes"]
    class_to_idx = {c: i for i, c in enumerate(classes)}

    if args.true_label not in class_to_idx:
        raise ValueError(f"--true_label must be one of: {list(class_to_idx.keys())}")

    model = ReceiptBinaryClassifier().to(device)
    model.load_state_dict(ckpt["model_state"])
    model.eval()

    tfm = transforms.Compose([transforms.Resize((224, 224)), transforms.ToTensor()])
    img = Image.open(args.image).convert("RGB")
    x = tfm(img).unsqueeze(0).to(device)
    y = torch.tensor([class_to_idx[args.true_label]], device=device)

    x.requires_grad_(True)
    logits = model(x)
    pred = int(logits.argmax(dim=1).item())

    loss_fn = nn.CrossEntropyLoss()
    loss = loss_fn(logits, y)
    model.zero_grad()
    loss.backward()

    grad = x.grad.detach()
    x_adv = fgsm_attack(x.detach(), grad, args.eps)

    with torch.no_grad():
        logits_adv = model(x_adv)
        pred_adv = int(logits_adv.argmax(dim=1).item())
        p_clean = torch.softmax(logits, dim=1).squeeze(0).cpu().tolist()
        p_adv = torch.softmax(logits_adv, dim=1).squeeze(0).cpu().tolist()

    to_pil = transforms.ToPILImage()
    adv_img = to_pil(x_adv.squeeze(0).cpu())
    adv_img.save(args.out)

    print("CLEAN:", {"pred": classes[pred], "probs": dict(zip(classes, map(float, p_clean)))})
    print("ADV  :", {"pred": classes[pred_adv], "probs": dict(zip(classes, map(float, p_adv)))})
    print("Saved adversarial image to:", args.out)

    if classes[pred] == args.true_label and classes[pred_adv] != args.true_label:
        print("[+] SUCCESS: Evasion achieved (misclassification).")
    else:
        print("[-] Not successful. Try increasing eps slightly (e.g., 0.03) or choose another image.")

if __name__ == "__main__":
    main()
