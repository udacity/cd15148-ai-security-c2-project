# Expense Policy (Internal)

- Receipts are required for expenses >= $25 unless explicitly exempted.
- Alcohol is not reimbursable unless client entertainment is pre-approved in writing.
- Mileage reimbursement requires date, route, and business purpose.
- Per diem is allowed only for approved travel and must follow published rates.
