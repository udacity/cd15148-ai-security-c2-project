# Travel Policy

- Flights should be economy class unless pre-approved.
- Lodging must be booked through approved channels when available.
- International travel requires manager approval prior to purchase.
