# Reimbursements FAQ

Q: Can I submit a manual receipt?
A: Yes, if it includes merchant, date, total, and itemization where applicable.

Q: How long do I have to submit?
A: 60 days from transaction date unless a documented exception exists.
