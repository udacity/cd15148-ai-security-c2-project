from fastapi import FastAPI
from pydantic import BaseModel
from rag import LocalRAG
from prompts import SYSTEM_PROMPT

app = FastAPI(title="Expense RAG Chatbot")

rag = LocalRAG()
rag.ingest_folder("data/policies")

class ChatIn(BaseModel):
    question: str
    top_k: int = 5

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/chat")
def chat(body: ChatIn):
    retrieved = rag.retrieve(body.question, k=body.top_k)
    # Retrieval-only baseline (safe default for student environment)
    return {
        "system_rules": SYSTEM_PROMPT,
        "question": body.question,
        "retrieved": retrieved,
        "answer": "Retrieval-only mode: review retrieved excerpts and respond per policy. (Swap in an LLM to generate.)"
    }
