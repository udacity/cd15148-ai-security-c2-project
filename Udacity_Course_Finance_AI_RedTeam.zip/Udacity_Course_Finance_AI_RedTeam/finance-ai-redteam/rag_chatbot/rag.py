import os
import glob
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer

class LocalRAG:
    def __init__(self, embed_model_name="all-MiniLM-L6-v2"):
        self.embedder = SentenceTransformer(embed_model_name)
        self.index = None
        self.chunks = []  # {text, source}
        self.dim = None

    def _chunk_text(self, text, source, chunk_size=700, overlap=100):
        text = text.replace("\r\n", "\n")
        out = []
        start = 0
        while start < len(text):
            end = min(len(text), start + chunk_size)
            chunk = text[start:end]
            out.append({"text": chunk, "source": source})
            start = max(end - overlap, end)
        return out

    def ingest_folder(self, folder):
        paths = glob.glob(os.path.join(folder, "*.md")) + glob.glob(os.path.join(folder, "*.txt"))
        all_chunks = []
        for p in paths:
            with open(p, "r", encoding="utf-8") as f:
                txt = f.read()
            all_chunks.extend(self._chunk_text(txt, source=os.path.basename(p)))

        self.chunks = all_chunks
        embeddings = self.embedder.encode([c["text"] for c in self.chunks], normalize_embeddings=True)
        embeddings = np.array(embeddings, dtype="float32")
        self.dim = embeddings.shape[1]
        self.index = faiss.IndexFlatIP(self.dim)
        self.index.add(embeddings)

    def retrieve(self, question, k=5):
        q = self.embedder.encode([question], normalize_embeddings=True)
        q = np.array(q, dtype="float32")
        scores, idxs = self.index.search(q, k)
        results = []
        for i, s in zip(idxs[0], scores[0]):
            if i < 0:
                continue
            c = self.chunks[i]
            results.append({"text": c["text"], "source": c["source"], "score": float(s)})
        return results
