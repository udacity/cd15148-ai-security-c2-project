import os
from dataclasses import dataclass
from typing import Tuple, List

import torch
from torch.utils.data import Dataset
from PIL import Image

@dataclass
class ReceiptSample:
    path: str
    label: int

class SimpleImageFolderBinary(Dataset):
    """
    Expects:
      data/receipts/train/pos/*.jpg
      data/receipts/train/neg/*.jpg
      data/receipts/val/pos/*.jpg
      data/receipts/val/neg/*.jpg
    """
    def __init__(self, root_dir: str, split: str, transform=None):
        self.root_dir = root_dir
        self.split = split
        self.transform = transform
        self.samples: List[ReceiptSample] = []

        for label_name, label in [("neg", 0), ("pos", 1)]:
            d = os.path.join(root_dir, split, label_name)
            if not os.path.isdir(d):
                continue
            for fn in os.listdir(d):
                if fn.lower().endswith((".png", ".jpg", ".jpeg", ".webp")):
                    self.samples.append(ReceiptSample(os.path.join(d, fn), label))

        if len(self.samples) == 0:
            raise FileNotFoundError(
                f"No images found under {root_dir}/{split}/(pos|neg). "
                "Add data or run SUBMISSION/05_repro_steps.md dataset instructions."
            )

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        s = self.samples[idx]
        img = Image.open(s.path).convert("RGB")
        if self.transform:
            img = self.transform(img)
        return img, torch.tensor(s.label, dtype=torch.long)
