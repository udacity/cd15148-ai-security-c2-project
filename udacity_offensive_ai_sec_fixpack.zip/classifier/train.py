import os
import json
import random
import argparse

import numpy as np
import torch
from torch.utils.data import DataLoader
from torchvision import transforms

from model import ReceiptBinaryCNN
from data import SimpleImageFolderBinary

def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

def accuracy(logits, y):
    preds = torch.argmax(logits, dim=1)
    return (preds == y).float().mean().item()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_root", default="data/receipts", help="Path to receipt dataset root")
    ap.add_argument("--epochs", type=int, default=5)
    ap.add_argument("--batch_size", type=int, default=32)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--seed", type=int, default=int(os.getenv("SEED", "1337")))
    ap.add_argument("--out_dir", default="checkpoints")
    args = ap.parse_args()

    set_seed(args.seed)
    device = "cuda" if torch.cuda.is_available() else "cpu"

    tfm = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
    ])

    train_ds = SimpleImageFolderBinary(args.data_root, "train", transform=tfm)
    val_ds   = SimpleImageFolderBinary(args.data_root, "val", transform=tfm)

    train_dl = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=0)
    val_dl   = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False, num_workers=0)

    model = ReceiptBinaryCNN().to(device)
    opt = torch.optim.Adam(model.parameters(), lr=args.lr)
    loss_fn = torch.nn.CrossEntropyLoss()

    os.makedirs(args.out_dir, exist_ok=True)

    best_val = 0.0
    history = []
    for epoch in range(1, args.epochs + 1):
        model.train()
        tr_loss = 0.0
        tr_acc = 0.0
        for xb, yb in train_dl:
            xb, yb = xb.to(device), yb.to(device)
            opt.zero_grad()
            logits = model(xb)
            loss = loss_fn(logits, yb)
            loss.backward()
            opt.step()
            tr_loss += loss.item()
            tr_acc += accuracy(logits.detach(), yb)

        tr_loss /= max(len(train_dl), 1)
        tr_acc /= max(len(train_dl), 1)

        model.eval()
        va_loss = 0.0
        va_acc = 0.0
        with torch.no_grad():
            for xb, yb in val_dl:
                xb, yb = xb.to(device), yb.to(device)
                logits = model(xb)
                loss = loss_fn(logits, yb)
                va_loss += loss.item()
                va_acc += accuracy(logits, yb)

        va_loss /= max(len(val_dl), 1)
        va_acc /= max(len(val_dl), 1)

        history.append({
            "epoch": epoch,
            "train_loss": tr_loss,
            "train_acc": tr_acc,
            "val_loss": va_loss,
            "val_acc": va_acc,
        })

        print(f"[epoch {epoch}] train loss {tr_loss:.4f} acc {tr_acc:.3f} | val loss {va_loss:.4f} acc {va_acc:.3f}")

        if va_acc > best_val:
            best_val = va_acc
            ckpt_path = os.path.join(args.out_dir, "receipt_cnn_clean.pt")
            torch.save({"model_state": model.state_dict(), "seed": args.seed, "args": vars(args)}, ckpt_path)
            print(f"  saved best checkpoint -> {ckpt_path}")

    with open(os.path.join(args.out_dir, "train_history.json"), "w", encoding="utf-8") as f:
        json.dump(history, f, indent=2)

if __name__ == "__main__":
    main()
