import os
import shutil
import argparse
import random
import json

import torch
from torch.utils.data import DataLoader
from torchvision import transforms

from model import ReceiptBinaryCNN
from data import SimpleImageFolderBinary

def poison_copy_dataset(src_root: str, dst_root: str, flip_rate: float, seed: int):
    """
    Copies src_root -> dst_root and flips labels for a fraction of training samples.
    Expected src structure: train/(pos|neg), val/(pos|neg)
    Output: same structure, with some train images moved across label dirs.
    """
    if os.path.exists(dst_root):
        shutil.rmtree(dst_root)
    shutil.copytree(src_root, dst_root)

    rng = random.Random(seed)
    moved = []

    for label_name in ["pos", "neg"]:
        d = os.path.join(dst_root, "train", label_name)
        if not os.path.isdir(d):
            continue
        files = [f for f in os.listdir(d) if f.lower().endswith((".png", ".jpg", ".jpeg", ".webp"))]
        rng.shuffle(files)
        k = int(len(files) * flip_rate)
        flip_files = files[:k]

        for fn in flip_files:
            src = os.path.join(d, fn)
            other = "neg" if label_name == "pos" else "pos"
            dst = os.path.join(dst_root, "train", other, fn)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.move(src, dst)
            moved.append({"file": fn, "from": label_name, "to": other})

    with open(os.path.join(dst_root, "poison_manifest.json"), "w", encoding="utf-8") as f:
        json.dump({"flip_rate": flip_rate, "seed": seed, "moved": moved}, f, indent=2)

    return moved

def train(data_root: str, out_ckpt: str, epochs: int, batch_size: int, lr: float, seed: int):
    random.seed(seed)
    torch.manual_seed(seed)
    device = "cuda" if torch.cuda.is_available() else "cpu"

    tfm = transforms.Compose([transforms.Resize((224, 224)), transforms.ToTensor()])

    train_ds = SimpleImageFolderBinary(data_root, "train", transform=tfm)
    val_ds   = SimpleImageFolderBinary(data_root, "val", transform=tfm)

    train_dl = DataLoader(train_ds, batch_size=batch_size, shuffle=True, num_workers=0)
    val_dl   = DataLoader(val_ds, batch_size=batch_size, shuffle=False, num_workers=0)

    model = ReceiptBinaryCNN().to(device)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = torch.nn.CrossEntropyLoss()

    best = 0.0
    for epoch in range(1, epochs + 1):
        model.train()
        for xb, yb in train_dl:
            xb, yb = xb.to(device), yb.to(device)
            opt.zero_grad()
            logits = model(xb)
            loss = loss_fn(logits, yb)
            loss.backward()
            opt.step()

        # val acc
        model.eval()
        correct = 0
        total = 0
        with torch.no_grad():
            for xb, yb in val_dl:
                xb, yb = xb.to(device), yb.to(device)
                pred = model(xb).argmax(dim=1)
                correct += int((pred == yb).sum().item())
                total += int(yb.numel())
        acc = correct / max(total, 1)
        print(f"[epoch {epoch}] val_acc={acc:.3f}")
        if acc > best:
            best = acc
            torch.save({"model_state": model.state_dict(), "seed": seed, "data_root": data_root}, out_ckpt)

    return best

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--clean_data_root", default="data/receipts", help="Clean dataset root")
    ap.add_argument("--poison_data_root", default="data/receipts_poisoned", help="Output poisoned dataset root")
    ap.add_argument("--flip_rate", type=float, default=0.05)
    ap.add_argument("--seed", type=int, default=1337)
    ap.add_argument("--epochs", type=int, default=5)
    ap.add_argument("--batch_size", type=int, default=32)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--out_dir", default="checkpoints")
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)

    moved = poison_copy_dataset(args.clean_data_root, args.poison_data_root, args.flip_rate, args.seed)
    print(f"Poisoned training set by moving {len(moved)} files (flip_rate={args.flip_rate}).")

    out_ckpt = os.path.join(args.out_dir, "receipt_cnn_poisoned.pt")
    best = train(args.poison_data_root, out_ckpt, args.epochs, args.batch_size, args.lr, args.seed)
    print(f"Saved poisoned checkpoint -> {out_ckpt} (best val acc: {best:.3f})")

if __name__ == "__main__":
    main()
