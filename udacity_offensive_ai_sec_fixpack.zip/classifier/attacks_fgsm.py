import argparse
import torch
from torchvision import transforms
from PIL import Image

from model import ReceiptBinaryCNN

LABELS = {0: "neg", 1: "pos"}

def fgsm_attack(x, grad, eps):
    return torch.clamp(x + eps * grad.sign(), 0.0, 1.0)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--image", required=True)
    ap.add_argument("--label", type=int, required=True, help="0=neg 1=pos (true label)")
    ap.add_argument("--ckpt", default="checkpoints/receipt_cnn_clean.pt")
    ap.add_argument("--eps", type=float, default=0.03)
    ap.add_argument("--out_adv", default="adv.png")
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"

    tfm = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
    ])

    img = Image.open(args.image).convert("RGB")
    x = tfm(img).unsqueeze(0).to(device)
    y = torch.tensor([args.label], dtype=torch.long).to(device)

    model = ReceiptBinaryCNN().to(device)
    ckpt = torch.load(args.ckpt, map_location=device)
    model.load_state_dict(ckpt["model_state"])
    model.eval()

    x.requires_grad_(True)
    logits = model(x)
    loss = torch.nn.CrossEntropyLoss()(logits, y)
    loss.backward()
    grad = x.grad.detach()

    x_adv = fgsm_attack(x.detach(), grad, args.eps)

    with torch.no_grad():
        p_clean = torch.softmax(model(x.detach()), dim=1)[0].cpu().numpy()
        p_adv = torch.softmax(model(x_adv), dim=1)[0].cpu().numpy()

    adv_img = transforms.ToPILImage()(x_adv.squeeze(0).cpu())
    adv_img.save(args.out_adv)

    print({
        "clean_pred": LABELS[int(p_clean.argmax())],
        "clean_probs": p_clean.tolist(),
        "adv_pred": LABELS[int(p_adv.argmax())],
        "adv_probs": p_adv.tolist(),
        "eps": args.eps,
        "out_adv": args.out_adv,
    })

if __name__ == "__main__":
    main()
