import argparse
import torch
from torchvision import transforms
from PIL import Image

from model import ReceiptBinaryCNN

LABELS = {0: "neg", 1: "pos"}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--image", required=True)
    ap.add_argument("--ckpt", default="checkpoints/receipt_cnn_clean.pt")
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"

    tfm = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
    ])

    img = Image.open(args.image).convert("RGB")
    x = tfm(img).unsqueeze(0).to(device)

    model = ReceiptBinaryCNN().to(device)
    ckpt = torch.load(args.ckpt, map_location=device)
    model.load_state_dict(ckpt["model_state"])
    model.eval()

    with torch.no_grad():
        logits = model(x)
        probs = torch.softmax(logits, dim=1).cpu().numpy()[0]
        pred = int(probs.argmax())
    print({"pred": LABELS[pred], "probs": probs.tolist()})

if __name__ == "__main__":
    main()
