import torch
import torch.nn as nn
import torch.nn.functional as F

class ReceiptBinaryCNN(nn.Module):
    """
    Simple 3-block CNN for binary receipt classification.

    Architecture (transparent for students):
      [Conv -> ReLU -> MaxPool] x 3
      Flatten
      FC -> ReLU -> Dropout
      FC -> logits (2 classes)
    """
    def __init__(self, in_channels: int = 3, num_classes: int = 2):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, 16, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(16, 32, kernel_size=3, padding=1)
        self.conv3 = nn.Conv2d(32, 64, kernel_size=3, padding=1)

        self.pool = nn.MaxPool2d(2, 2)
        self.dropout = nn.Dropout(p=0.3)

        # input images expected 224x224 by default in this repo transforms
        # after 3 pools => 224/8 = 28
        self.fc1 = nn.Linear(64 * 28 * 28, 128)
        self.fc2 = nn.Linear(128, num_classes)

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))  # 224 -> 112
        x = self.pool(F.relu(self.conv2(x)))  # 112 -> 56
        x = self.pool(F.relu(self.conv3(x)))  # 56 -> 28
        x = torch.flatten(x, 1)
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        return self.fc2(x)
