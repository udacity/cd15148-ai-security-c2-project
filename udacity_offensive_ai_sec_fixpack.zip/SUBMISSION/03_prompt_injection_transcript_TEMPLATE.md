# Prompt Injection Transcript (Template)

**Date:** YYYY-MM-DD  
**Model:** <LLM_MODEL>  
**Endpoint:** <LLM_API_URL>  

## User Prompt (Injection)
Paste the exact injection prompt you used.

## Assistant Output (Verbatim)
Paste the full LLM-generated response output (or JSON snippet).

## Analysis
- What instruction boundary failed (system vs user)?
- What retrieval context contributed?
- What mitigations would reduce success rate? (e.g., prompt hardening, output filtering, per-doc access control, RAG sanitization, tool gating)
