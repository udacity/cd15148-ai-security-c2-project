#!/usr/bin/env bash
set -euo pipefail

IMAGE_NAME="${1:-udacity-offensive-ai-sec:latest}"
OUT="SUBMISSION/06_trivy_report.json"

if ! command -v trivy >/dev/null 2>&1; then
  echo "ERROR: trivy not found. Install it in the workspace, then re-run."
  echo "See: https://aquasecurity.github.io/trivy/latest/getting-started/installation/"
  exit 1
fi

echo "[*] Scanning image: ${IMAGE_NAME}"
trivy image --format json --output "${OUT}" "${IMAGE_NAME}"

echo "[+] Wrote: ${OUT}"
