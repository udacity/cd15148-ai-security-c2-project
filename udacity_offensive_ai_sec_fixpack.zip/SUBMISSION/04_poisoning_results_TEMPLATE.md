# Poisoning Results (Template)

## Setup
- Flip rate:
- Seed:
- Epochs:
- Clean checkpoint:
- Poisoned checkpoint:

## Results
| Model | Val Accuracy | Notes |
|---|---:|---|
| Clean |  |  |
| Poisoned |  |  |

## Discussion
- Did performance degrade overall or in a specific class?
- How would you detect poisoning in a pipeline?
- What controls would you add? (data validation, provenance, robust training, audits)
