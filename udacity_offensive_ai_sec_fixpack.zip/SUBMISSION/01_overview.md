# Project Overview (Revised Scope)

This project demonstrates **four offensive AI security attacks** and the corresponding defensive considerations:

1) **Evasion (FGSM)** against a custom CNN image classifier (trained from scratch).
2) **Data poisoning (label flipping)** during training to degrade or bias performance.
3) **Prompt injection** against a RAG chatbot connected to a real classroom LLM.
4) **RAG data exfiltration** attempt targeting a *fictional* confidential document in the knowledge base.

All datasets and sensitive artifacts are fictional or curated for educational use.
