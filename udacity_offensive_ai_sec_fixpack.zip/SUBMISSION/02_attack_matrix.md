# Attack Matrix (Deliverable)

| Attack | Target | Technique | Student Evidence |
|---|---|---|---|
| FGSM evasion | Image classifier | Gradient-sign perturbation | Clean vs adversarial prediction + saved adv image |
| Label flipping | Training pipeline | Flip ≤5% training labels | Poison manifest + clean vs poisoned metrics |
| Prompt injection | RAG assistant | Instruction hierarchy override | Prompt Injection Transcript (LLM output) |
| Data exfiltration | RAG knowledge base | Attempt extraction of confidential doc | Transcript + mitigation recommendations |
