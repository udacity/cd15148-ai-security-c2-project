import os
import glob
import json
import argparse
from typing import List

import numpy as np
import faiss

from rag import SimpleFAISSRAG

def chunk_text(text: str, chunk_size: int = 700, overlap: int = 80) -> List[str]:
    text = text.strip()
    chunks = []
    i = 0
    while i < len(text):
        j = min(len(text), i + chunk_size)
        chunks.append(text[i:j])
        i = j - overlap
        if i < 0:
            i = 0
        if j == len(text):
            break
    return chunks

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", default="rag_chatbot/data/policies")
    ap.add_argument("--out_dir", default="rag_chatbot/index")
    ap.add_argument("--dim", type=int, default=1536, help="Embedding dimension for your classroom model")
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)

    rag = SimpleFAISSRAG(dim=args.dim)

    md_files = sorted(glob.glob(os.path.join(args.data_dir, "*.md")))
    if not md_files:
        raise FileNotFoundError(f"No .md files found under {args.data_dir}")

    manifest = []
    for fp in md_files:
        doc_id = os.path.basename(fp)
        with open(fp, "r", encoding="utf-8") as f:
            txt = f.read()
        chunks = chunk_text(txt)
        rag.add(doc_id, chunks)
        manifest.append({"doc_id": doc_id, "chunks": len(chunks)})

    # Save FAISS + chunk store
    faiss.write_index(rag.index, os.path.join(args.out_dir, "faiss.index"))
    with open(os.path.join(args.out_dir, "chunks.jsonl"), "w", encoding="utf-8") as f:
        for c in rag.chunks:
            f.write(json.dumps({"doc_id": c.doc_id, "text": c.text}) + "\n")

    with open(os.path.join(args.out_dir, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump({"dim": args.dim, "docs": manifest}, f, indent=2)

    print(f"Built index with {len(rag.chunks)} chunks from {len(md_files)} docs -> {args.out_dir}")

if __name__ == "__main__":
    main()
