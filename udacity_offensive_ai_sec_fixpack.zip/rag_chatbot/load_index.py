import os
import json
from typing import List

import faiss

from rag import SimpleFAISSRAG, Chunk

def load_rag(index_dir: str) -> SimpleFAISSRAG:
    manifest_path = os.path.join(index_dir, "manifest.json")
    with open(manifest_path, "r", encoding="utf-8") as f:
        manifest = json.load(f)
    dim = int(manifest["dim"])

    rag = SimpleFAISSRAG(dim=dim)
    rag.index = faiss.read_index(os.path.join(index_dir, "faiss.index"))

    chunks_path = os.path.join(index_dir, "chunks.jsonl")
    chunks: List[Chunk] = []
    with open(chunks_path, "r", encoding="utf-8") as f:
        for line in f:
            obj = json.loads(line)
            chunks.append(Chunk(doc_id=obj["doc_id"], text=obj["text"]))
    rag.chunks = chunks
    return rag
