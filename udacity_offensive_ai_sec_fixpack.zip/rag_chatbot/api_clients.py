import os
import json
import requests
from typing import List, Dict, Any

class ClassroomEmbeddingClient:
    def __init__(self):
        self.url = os.getenv("EMBEDDING_API_URL", "").strip()
        self.key = os.getenv("EMBEDDING_API_KEY", "").strip()
        self.model = os.getenv("EMBEDDING_MODEL", "").strip()

    def embed(self, texts: List[str]) -> List[List[float]]:
        if not self.url or not self.key or not self.model:
            raise RuntimeError("Missing EMBEDDING_API_URL/KEY/MODEL. See .env.example")
        headers = {
            "Authorization": f"Bearer {self.key}",
            "Content-Type": "application/json",
        }
        payload = {"model": self.model, "input": texts}
        r = requests.post(self.url, headers=headers, data=json.dumps(payload), timeout=60)
        r.raise_for_status()
        data = r.json()
        # Expect OpenAI-style embeddings: {"data":[{"embedding":[...]}]}
        return [item["embedding"] for item in data["data"]]

class ClassroomLLMClient:
    def __init__(self):
        self.url = os.getenv("LLM_API_URL", "").strip()
        self.key = os.getenv("LLM_API_KEY", "").strip()
        self.model = os.getenv("LLM_MODEL", "").strip()

    def chat(self, messages: List[Dict[str, str]], temperature: float = 0.2) -> str:
        if not self.url or not self.key or not self.model:
            raise RuntimeError("Missing LLM_API_URL/KEY/MODEL. See .env.example")
        headers = {
            "Authorization": f"Bearer {self.key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
        }
        r = requests.post(self.url, headers=headers, data=json.dumps(payload), timeout=120)
        r.raise_for_status()
        data = r.json()
        # Expect OpenAI-style chat: choices[0].message.content
        return data["choices"][0]["message"]["content"]
