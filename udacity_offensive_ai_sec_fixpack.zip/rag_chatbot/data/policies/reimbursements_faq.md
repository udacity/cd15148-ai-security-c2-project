# Reimbursements FAQ

Q: When do I get reimbursed?
A: Typically within 10 business days.
