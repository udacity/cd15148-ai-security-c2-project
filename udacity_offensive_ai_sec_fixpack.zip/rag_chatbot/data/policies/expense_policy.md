# Expense Policy

Employees may submit receipts for reimbursement per standard policy.
