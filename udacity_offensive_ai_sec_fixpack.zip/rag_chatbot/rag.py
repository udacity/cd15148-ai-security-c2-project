import os
from dataclasses import dataclass
from typing import List, Tuple

import faiss
import numpy as np

from api_clients import ClassroomEmbeddingClient

@dataclass
class Chunk:
    doc_id: str
    text: str

class SimpleFAISSRAG:
    def __init__(self, dim: int):
        self.dim = dim
        self.index = faiss.IndexFlatIP(dim)
        self.chunks: List[Chunk] = []
        self.embedder = ClassroomEmbeddingClient()

    @staticmethod
    def _normalize(v: np.ndarray) -> np.ndarray:
        n = np.linalg.norm(v, axis=1, keepdims=True) + 1e-12
        return v / n

    def add(self, doc_id: str, texts: List[str]):
        embs = self.embedder.embed(texts)
        X = np.array(embs, dtype=np.float32)
        X = self._normalize(X)
        self.index.add(X)
        self.chunks.extend([Chunk(doc_id=doc_id, text=t) for t in texts])

    def query(self, q: str, top_k: int = 4) -> List[Tuple[float, Chunk]]:
        embs = self.embedder.embed([q])
        xq = np.array(embs, dtype=np.float32)
        xq = self._normalize(xq)
        scores, idxs = self.index.search(xq, top_k)
        out = []
        for s, i in zip(scores[0].tolist(), idxs[0].tolist()):
            if i == -1:
                continue
            out.append((s, self.chunks[i]))
        return out
