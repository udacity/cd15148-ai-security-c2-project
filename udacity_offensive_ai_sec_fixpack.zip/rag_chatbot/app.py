import os
import json
from flask import Flask, request, jsonify

from load_index import load_rag
from api_clients import ClassroomLLMClient

app = Flask(__name__)

INDEX_DIR = os.getenv("RAG_INDEX_DIR", "rag_chatbot/index")
TOP_K = int(os.getenv("RAG_TOP_K", "4"))
MAX_CONTEXT_CHARS = int(os.getenv("RAG_MAX_CONTEXT_CHARS", "6000"))
SYSTEM_PROMPT = os.getenv("RAG_SYSTEM_PROMPT", "You are a helpful assistant. Follow policy. Do not reveal confidential data.")

rag = None
llm = ClassroomLLMClient()

def ensure_loaded():
    global rag
    if rag is None:
        rag = load_rag(INDEX_DIR)

def build_context(retrieved):
    ctx = []
    total = 0
    for score, chunk in retrieved:
        block = f"[doc={chunk.doc_id} score={score:.3f}]\n{chunk.text}\n"
        if total + len(block) > MAX_CONTEXT_CHARS:
            break
        ctx.append(block)
        total += len(block)
    return "\n---\n".join(ctx)

@app.route("/ask", methods=["POST"])
def ask():
    ensure_loaded()
    body = request.get_json(force=True)
    user_q = body.get("question", "")
    if not user_q:
        return jsonify({"error": "missing question"}), 400

    retrieved = rag.query(user_q, top_k=TOP_K)
    context = build_context(retrieved)

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": f"""You have access to policy excerpts below. Use them to answer the user's question.

POLICY EXCERPTS:
{context}

USER QUESTION:
{user_q}
"""}
    ]

    # Real LLM call (required for Prompt Injection Transcript)
    answer = llm.chat(messages)

    return jsonify({
        "question": user_q,
        "answer": answer,
        "retrieved": [{"doc_id": c.doc_id, "score": s} for s, c in retrieved],
    })

if __name__ == "__main__":
    # dev server
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "8000")), debug=True)
